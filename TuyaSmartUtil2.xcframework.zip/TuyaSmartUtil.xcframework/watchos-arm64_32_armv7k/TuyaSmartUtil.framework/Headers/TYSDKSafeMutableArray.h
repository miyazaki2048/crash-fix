//
//  TYSDKSafeMutableArray.h
//  TuyaSmartUtil
//
//  Copyright (c) 2014-2021 Tuya Inc. (https://developer.tuya.com)
//

#import <Foundation/Foundation.h>

// The thread-safe class.
@interface TYSDKSafeMutableArray<ObjectType> : NSMutableArray

@end
